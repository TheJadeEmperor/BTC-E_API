<?php
require_once __DIR__.'/EmailImporter.php';

/**
 *  Important: Goto the gmail and make less secure toggle button to off so imap will able to fetch emails
 *  Enter: email and password in relevent fields below
 *  if maximum execution time issue occurs uncomment the below init_set function to increase max execution time
 */

/**
 * Creating connection by calling constructor of EmailImporter class
 */

//ini_set('max_execution_time', 300);
$mails = new EmailImporter( '{imap.gmail.com:993/imap/ssl}INBOX','email@example.com','password');

/**
 * Printing RESULTS here
 * Important: Try to fetch plan emails so you will get clean objects otherwise ragex functions of php will use to clean the emails
 * Possible getter methods are
 * 1. getMailsReceivedFrom
 * 2. getMailsSentTo
 * 3. getMailsBySubject
 * 4. getMailsByKeyword
 * 5. getMailsUnseen
 * 6. getAllEmails
 */

echo"<pre>";
print_r($mails->getMailsBySubject("Enter Subject here"));


// Thanks